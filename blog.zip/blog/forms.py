from django import forms
from .models import BlogPost,NewsletterUser

class PostCreationForm(forms.ModelForm):
    postContent= forms.CharField(widget= forms.TextInput(attrs={'id':'mytextarea'}))
    class Meta:
        model=BlogPost
        fields=('postTitle','postContent','category','author','postImage')

        def clean_date(self):
            postTitle=self.cleaned_data('postTitle')
            postContent=self.cleaned_data('postContent')
            category=self.cleaned_data('category')
            author=self.cleaned_data('author')

            return postTitle,postContent,category,author

class NewsletterForm(forms.ModelForm):
    email=forms.EmailField(label='',widget=forms.TextInput(attrs={'placeholder':'Email'}))

    class Meta:
        model=NewsletterUser
        fields=('email',)

    def clean_email(self):
        email=self.cleaned_data.get('email')
        return email
