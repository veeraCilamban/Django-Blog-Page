from django.urls import path
from django.conf.urls import include
from . import views
#from blog.views import Blog,Blog_Detail,Search_View,Create
from blog import views
urlpatterns=[
    path('',views.HomeBlog.as_view(),name="blog"),
    path('tinymce/',include('tinymce.urls')),
    path('posts/',views.BlogPosts.as_view(),name='posts'),
    path('details/<slug:slug>/<int:id>/',views.Blog_Detail.as_view(),name="details"),
    path('search/',views.Search_View.as_view(),name='searchResults'),
    path('hitcount/', include(('hitcount.urls', 'hitcount'), namespace='hitcount')),

]
