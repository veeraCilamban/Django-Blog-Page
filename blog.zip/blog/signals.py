'''from django.db.models.signals import post_save
from django.dispatch import receiver
from mysite.models import BlogPost,NewsletterUser
from django.core.mail import send_mail
from blog.settings import EMAIL_HOST_USER

@receiver(post_save, sender=BlogPost)
def SendEmail(sender , instance, created, **kwargs):
    if created:
        emails = list(NewsletterUser.objects.values('email'))
        recepients = []
        for i in range(0, len(emails)):
            recepients.append(emails[i]['email'])

        send_mail('New post on blog', str(instance.title), EMAIL_HOST_USER, recepients, fail_silently=False)
email=EmailMessage(subject,message,from_email,recepients)
email.content_subtype="html"
html_template=get_template("blog/postUpdateMail.html").render()
email.attach(html_template,'text/html')'''
