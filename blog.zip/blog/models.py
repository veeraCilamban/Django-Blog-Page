from django.db import models
from django.conf import settings
from django.urls import reverse
from django.core.mail import send_mail,EmailMultiAlternatives
from django.template.loader import get_template
from django.db.models.signals import post_save
from django.utils.text import slugify,Truncator
from tinymce.models import HTMLField
from django.template import Context
from email.mime.image import MIMEImage
from hitcount.models import HitCountMixin, HitCount
from django.contrib.contenttypes.fields import GenericRelation


# Create your models here.
class NewsletterUser(models.Model):
    email=models.EmailField()
    timeadded=models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.email


class BlogPost(models.Model,HitCountMixin):
    EMAIL_STATUS_CHOICES=(('Draft','Draft'),('Published','Published'))
    postTitle=models.CharField(max_length=150)
    postContent=HTMLField()
    category=models.CharField(max_length=50)
    author=models.CharField(max_length=100)
    postImage=models.ImageField(upload_to='Post_Images',null=True,blank=True,default='default.png')
    status=models.CharField(max_length=10,choices=EMAIL_STATUS_CHOICES,default='Published')
    updated=models.DateTimeField(auto_now=True,auto_now_add=False)
    timestamp=models.DateTimeField(auto_now=False,auto_now_add=True)
    slug = models.SlugField(default="queryTitle")
    hit_count_generic = GenericRelation(HitCount, object_id_field='object_pk',
     related_query_name='hit_count_generic_relation')


    def __unicode__(self):
        return self.postTitle

    def __str__(self):
        return self.postTitle

    def get_absolute_url(self):
        return reverse('details',kwargs={"id":self.id,"slug":self.slug})

    def save(self,*args,**kwargs):
        self.slug=slugify(self.postTitle) + "-" + str(self.id)
        super().save(*args,**kwargs)

def sendUpdateMail(sender,created,instance,**kwargs):
    if created:
        if instance.status == 'Published':
            subject=instance.postTitle
            message=Truncator(instance.postContent).words(30)
            from_email=settings.EMAIL_HOST_USER
            email=list(NewsletterUser.objects.values('email'))
            d={'postContent':instance.postContent,'title':subject,'myurl':instance.get_absolute_url}
            recepients=[]
            html_templatey=get_template("blog/postUpdateMail.html").render(d)
            #recepients=[p.email for p in NewsletterUser.objects.all()]
            for p in NewsletterUser.objects.all():
                recepients.append(p.email)
                email=EmailMultiAlternatives(subject,'',from_email,recepients)
                email.attach_alternative(html_templatey,'text/html')
                #image=MIMEImage(instance.postImage.url)
                #email.attach(image)
                #image.add_header('Content-ID',f"<{'img'}>")
                email.send()
                recepients=[]


post_save.connect(sendUpdateMail,sender=BlogPost)
