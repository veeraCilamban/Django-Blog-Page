from django.conf import settings
from django.shortcuts import render,get_object_or_404,redirect
from django.db.models import Q
from django.views.generic import TemplateView
from hitcount.views import HitCountDetailView
from django.contrib import messages
from django.core.mail import send_mail,EmailMultiAlternatives
from django.template.loader import get_template
from django.db.models import Count
from django.views import View
from django.core.paginator import Paginator,PageNotAnInteger,EmptyPage
from .models import BlogPost,NewsletterUser
from .forms import PostCreationForm,NewsletterForm

# Create your views here.
class BlogPosts(View):
    template_name='blog/blog.html'
    def get(self,request):
        allPost=BlogPost.objects.filter().order_by('-updated')
        args={'allPost':allPost}
        return render(request,self.template_name,args)

class HomeBlog(View):
    template_name='blog/blogHome.html'
    def get(self,request):
        form=NewsletterForm()
        recentPost=BlogPost.objects.filter().order_by('updated')
        popular_posts=BlogPost.objects.order_by('-hit_count_generic__hits')[:3]
        page=request.GET.get('page',1)
        paginator=Paginator(recentPost,1)
        try:
            self.posts=paginator.page(page)
        except PageNotAnInteger:
            self.posts=paginator.page(1)
        except EmptyPage:
            self.posts=paginator.page(paginator.num_pages)
        args={"recentPost":self.posts,'poppost':popular_posts,'form':form,'page':page}
        return render(request,self.template_name,args)
    def post(self,request):
        form=NewsletterForm(request.POST or None)
        if form.is_valid():
            instanceMail=form.save(commit=False)
            if NewsletterUser.objects.filter(email=instanceMail.email).exists():
                messages.warning(request,"Your Email is aldready exists","alert alert-danger alert-dismissible")
                return redirect('blog')

            else:
                instanceMail.save()
                messages.success(request,"Your Email" +"\t" +instanceMail.email +"\t"+"has  been saved...Stay connected :)","alert alert-success alert-dismissible ")
                subject="Thank you for Joining in JOBvsJOB"
                from_email=settings.EMAIL_HOST_USER
                to_email=[instanceMail.email]
                d={}
                html_templatey=get_template("blog/UserSubscribeMail.html").render(d)
                welcomemessage="Welcome to JOBvsJOB stay connected to get day to day update... to unsubsribe visit http://jobvsjob.com/blog/unsubsribe"
                email=EmailMultiAlternatives(subject,'',from_email,to_email)
                email.attach_alternative(html_templatey,'text/html')
                email.send()
                #send_mail(subject=subject,from_email=from_email,recipient_list=to_email,message='',fail_silently=False)
                return redirect('blog')
                form=NewsletterForm()
        args={"form":form}
        return render(request,self.template_name,args)


class Blog_Detail(HitCountDetailView):
    model=BlogPost
    template_name = 'blog/blogDetail.html'
    context_object_name = 'post'
    slug_field = 'slug'
    count_hit = True

    def get_context_data(self, **kwargs):
        instance = super(Blog_Detail, self).get_context_data(**kwargs)
        instance.update({
        'popular_posts': BlogPost.objects.order_by('-hit_count_generic__hits')[:3],
        'recent_posts': BlogPost.objects.filter().order_by('-updated')[:3],
        })
        return instance

    '''def gett(self,request):
        recent_posts=BlogPost.objects.filter().order_by('-updated')[:3]
        args={'recentPost':recent_posts}
        return render(request,'blog/blogDetail.html',args)'''

    '''def get(self,request,slug,id=None):
        instance=get_object_or_404(BlogPost,id=id)
        args={"instance":instance}
        return render(request,'blog/blogDetail.html',args)'''

class Search_View(View):
    def get(self,request):
        query=request.GET.get('q')
        results=BlogPost.objects.filter(Q(postTitle__icontains=query)|Q(author__icontains=query))
        args={"query":query,"results":results,"leng":len(results)}
        return render(request,"blog/searchResults.html",args)


'''class Create(View):
    def get(self,request):
        form=PostCreationForm(request.POST or None)
        if form.is_valid():
            post=form.save()
            form=PostCreationForm()
            return redirect('blog')
        else:
            print('error')
        args={'form':form}
        return render(request,'blog/createPost.html',args)'''
