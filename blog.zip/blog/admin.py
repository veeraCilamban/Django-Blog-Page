from django.contrib import admin
from .models import BlogPost,NewsletterUser
# Register your models here.

class BlogPostModelAdmin(admin.ModelAdmin):
    list_display=["postTitle","timestamp"]

    class Meta:
        model=BlogPost

class NewsletterModelAdmin(admin.ModelAdmin):
    list_display=["email","timeadded"]

    class Meta:
        model=NewsletterUser

admin.site.register(BlogPost,BlogPostModelAdmin)

admin.site.register(NewsletterUser,NewsletterModelAdmin)
